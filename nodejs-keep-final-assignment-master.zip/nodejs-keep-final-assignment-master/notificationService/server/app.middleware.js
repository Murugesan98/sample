const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const log = require('./logging');

log.info('Setting up API middleware');

const setMiddleware = (app) => {
  app.use(bodyParser.json());
  app.use(bodyParser.urlencoded({ extended: false }));
  app.use(cors());
}

module.exports = {
  setMiddleware
};
