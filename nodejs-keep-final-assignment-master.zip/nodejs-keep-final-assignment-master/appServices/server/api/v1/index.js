const router = require('express').Router();

const authService = require('../../services').authServices;

router.use('/users', require('./users'));
router.use('/notes', authService.checkAuthentication, require('./notes'));

module.exports = router;
