const { appConfig, dbConfig, authConfig, logConfig } = require('./appConfig');

module.exports = {
  appConfig,
  dbConfig,
  authConfig,
  logConfig
}
