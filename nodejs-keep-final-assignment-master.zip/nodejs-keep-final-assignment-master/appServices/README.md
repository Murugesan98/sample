## Notes Application (API services)
This is a simple node.js application with MongoDB access, can be used to implementation for CRUD operations with MongoDB

This expects the environment variable MONGO_URL, which you can set using below command 

On Linux platform
```
export MONGO_URL='mongodb://localhost:27017/testDB'
echo Testing - $MONGO_URL
```

On Windows platform
```
SET MONGO_URL='mongodb://localhost:27017/testDB'
echo Testing - %MONGO_URL%
```

### Application Details:
- User can register and login & logout
- User can perform CRUD operations on notes, notification and reminder feature is included
- User can shared note with other users

### API Specification:

- Register:POST http://localhost:3000/api/v1/users/register
Body: ```{ "username": <username>, "password": <password> }```

- Login: 
POST http://localhost:3000/api/v1/users/login
Body: ```{ "username": <username>, "password": <password> }```

- Get all usernames: 
GET http://localhost:3000/api/v1/users/getall
Headers: ```Authorization Bearer <jwt-token>```


- Get all notes for a user: 
GET http://localhost:3000/api/v1/notes
Headers: ```Authorization Bearer <jwt-token>```

- Add a note for a user: 
POST http://localhost:3000/api/v1/notes
Body: ```{ "title": <title>, "text": <text>, "state": <state> }```
Headers: ```Authorization Bearer <jwt-token>```

- Update a note for a user: 
PUT http://localhost:3000/api/v1/notes/<noteId>
Body: ```{ "title": <title>, "text": <text>, "state": <state>, "isFavourite": <isFavourite>, "groupName": <groupName> }```
Headers: ```Authorization Bearer <jwt-token>```

- Get all notes for a user as stream: 
GET http://localhost:3000/api/v1/notes/stream
Headers: ```Authorization Bearer <jwt-token>```

- Insert bulk notes for a user: 
POST http://localhost:3000/api/v1/notes/stream
Headers: ```Authorization Bearer <jwt-token>```
Body: ```[{ "title": <title>, "text": <text>, "state": <state> }]```

- Delete note for a user: 
DELETE http://localhost:3000/api/v1/notes/:noteId
Headers: ```Authorization Bearer <jwt-token>```

- Delete note for a user: 
DELETE http://localhost:3000/api/v1/notes/
Headers: ```Authorization Bearer <jwt-token>```
Body: ```[ noteId1, noteId2, ... ]```

- Add bulk notes to Favourites for a user: 
POST http://localhost:3000/api/v1/notes/favourites
Headers: ```Authorization Bearer <jwt-token>```
Body: ```[ noteId1, noteId2, ... ]```

- Add bulk notes to a group for a user: 
POST http://localhost:3000/api/v1/notes/group/:groupName
Headers: ```Authorization Bearer <jwt-token>```
Body: ```[ noteId1, noteId2, ... ]```

### How to run this project

1. Install dependencies

```
npm install
```

or

```
yarn
```

2. Run application from terminal

```
npm start
```

3. Run test cases from terminal

```
npm run test
```

4. Run lint checks from terminal

```
npm run lint
```
