export const environment = {
  production: true,
  appServicesUrl: 'http://localhost:3000/',
  notifyServicesUrl: 'http://localhost:3003/'
};
